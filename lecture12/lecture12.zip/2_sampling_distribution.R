#**************************************
# lecture 12: sampling distribution
# jangsea.park@boxnwhis.kr
# 2015-07-15
#**************************************

# make height data --------------------------------------------------------

size_pop <- 10000000
height_pop <- rnorm(size_pop, 174, 6)
hist(height_pop)
mean(height_pop)

# sampling distribution of sample mean ------------------------------------

n_sampling <- 100
size_sample <- 1000
sample_means <- vector()
for (i in seq(n_sampling)) {
    height_sample <- height_pop[sample(size_pop, size_sample)]
    sample_mean <- mean(height_sample)
    sample_means <- c(sample_means, sample_mean)
}

hist(sample_means)

# make dice data ----------------------------------------------------------

size_pop <- 10000000
dice_pop <- sample(6, size_pop, replace=T)
hist(dice_pop)
mean(dice_pop)

# sampling distribution of sample mean ------------------------------------

n_sampling <- 100
size_sample <- 1000
sample_means <- vector()
for (i in seq(n_sampling)) {
    dice_sample <- dice_pop[sample(size_pop, size_sample)]
    sample_mean <- mean(dice_sample)
    sample_means <- c(sample_means, sample_mean)
}

hist(sample_means)
