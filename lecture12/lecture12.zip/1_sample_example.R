#**********************************
# lecture 12: sampling
# jangsea.park@boxnwhis.kr
# 2015-07-15
#**********************************

# install packages --------------------------------------------------------

ifelse('ggplot2' %in% rownames(installed.packages()), 'pass', install.packages('ggplot2'))

# load packages -----------------------------------------------------------

library(ggplot2)

# read data ---------------------------------------------------------------

filename <- list.files(pattern='*.csv')
bank_pop <- read.table(filename, header=T, stringsAsFactor=F, sep=';')
head(bank_pop)
str(bank_pop)

# make sample data --------------------------------------------------------

sample_size <- 1000
rn_sample <- sample(nrow(bank_pop), sample_size)
bank_sample <- bank_pop[rn_sample,]

# compare population and sample -------------------------------------------

# summary
summary(bank_pop$age)
summary(bank_sample$age)

# draw density
plot_df <- data.frame(age = c(bank_pop$age, bank_sample$age),
                      group = c(rep('pop', nrow(bank_pop)), rep('sample', nrow(bank_sample))))
ggplot(plot_df, aes(x=age, color=group)) +
    geom_density()
