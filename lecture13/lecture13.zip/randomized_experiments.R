#************************************
# FastCampus #13
# randomized experimental subjects
# 2015-07-21
# jangsea.park@boxnwhis.kr
#************************************

# make experimental subjects ----------------------------------------------

n_customers <- 10000
data_customers <- round(rlnorm(n_customers))
summary(data_customers)
table(data_customers)
hist(data_customers, breaks = max(data_customers))

# make outliers -----------------------------------------------------------

n_outliers <- 1000
rownumber_outliers <- sample(1:length(data_customers), n_outliers)
data_customers[rownumber_outliers] <- 100

table(data_customers)
hist(data_customers, breaks = 100)

# make randomized groups --------------------------------------------------

rownumber_A <- sample(length(data_customers), length(data_customers) / 2)
group_A <- data_customers[rownumber_A]
table(group_A)
table(group_A)['100']

# simulate ----------------------------------------------------------------

counts_outliers <- vector()
for (i in 1:1000) {
    rownumber_A <- sample(length(data_customers), length(data_customers) / 2)
    group_A <- data_customers[rownumber_A]
    count_outlers <- table(group_A)['100']
    counts_outliers <- c(counts_outliers, count_outlers)
}

summary(counts_outliers)
hist(counts_outliers)
