#******************************
# FastCampus lecture 14
# two sample test
# jangsea.park@gmail.com
# 2015-07-23
#******************************

# experiment 1 --------------------------------------------------------------

mean_a <- 35
sd_a <- 10
n_a <- 1000

mean_b <- 40
sd_b <- 8
n_b <- 800

x <- seq(30, 45, by = 0.01)
plot(x, dnorm(x, mean_a, sd_a / sqrt(n_a)), type = 'l', ylim = c(0, 1.5), ylab = '')
lines(x, dnorm(x, mean_b, sd_b / sqrt(n_b)), type = 'l')

# experiment 2 ------------------------------------------------------------

mean_a <- 35
sd_a <- 20
n_a <- 200

mean_b <- 40
sd_b <- 15
n_b <- 150

x <- seq(30, 45, by = 0.01)
plot(x, dnorm(x, mean_a, sd_a / sqrt(n_a)), type = 'l', ylim = c(0, .5), ylab = '')
lines(x, dnorm(x, mean_b, sd_b / sqrt(n_b)), type = 'l')

# 95% confidence intervals
qnorm(c(.025, .975), mean_a, sd_a / sqrt(n_a))
qnorm(c(.025, .975), mean_b, sd_b / sqrt(n_b))

# test statistic
plot(seq(-2, 12, by = .01), 
     dnorm(seq(-2, 12, by = .01), 
           mean_b - mean_a, 
           sqrt(sd_a^2 / n_a + sd_b^2 / n_b)),
     type = 'l',
     xlab = 'd',
     ylab = 'density')
segments(0, 0, 0, .2)

pnorm(0, mean_b - mean_a, sqrt(sd_a^2 / n_a + sd_b^2 / n_b))
