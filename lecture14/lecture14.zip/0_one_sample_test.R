#******************************
# FastCampus lecture 14
# one sample test
# jangsea.park@gmail.com
# 2015-07-23
#******************************

# normal dist. ------------------------------------------------------------

plot_normal_dist <- function(mean = 0, sd = 1) {
    x <- seq(-sd * 4 + mean, sd * 4 + mean, by = 0.01)
    y <- dnorm(x, mean = mean, sd = sd)
    plot(x, y, type = 'l', ylab = 'dnorm(x)')
}


# experiment 1--------------------------------------------------------------

mean = 35
sd = 12
n = 1000

x <- seq(20, 50, by = 0.01)
y <- dnorm(x, mean = mean, sd = sd / sqrt(n))
plot(x, y, type = 'l', ylab = 'dnorm(x)')
segments(30, 0, 30, max(y))

pnorm(30, mean, sd / sqrt(n))

# experiment 2 ------------------------------------------------------------

mean = 35
sd = 12
n = 50

x <- seq(20, 50, by = 0.01)
y <- dnorm(x, mean = mean, sd = sd / sqrt(n))
plot(x, y, type = 'l', ylab = 'dnorm(x)')
segments(30, 0, 30, max(y))

pnorm(30, mean, sd / sqrt(n))

# experiment 3 ------------------------------------------------------------

mean = 35
sd = 12
n = 10

x <- seq(20, 50, by = 0.01)
y <- dnorm(x, mean = mean, sd = sd / sqrt(n))
plot(x, y, type = 'l', ylab = 'dnorm(x)')
segments(30, 0, 30, max(y))

pnorm(30, mean, sd / sqrt(n))
