#******************************
# FastCampus lecture 14
# two sample test - proportion
# jangsea.park@gmail.com
# 2015-07-23
#******************************

# experiment1 -------------------------------------------------------------

n_a <- 1272
pu_a <- 221
n_b <- 1311
pu_b <- 210

prop_a <- pu_a / n_a
prob_b <- pu_b / n_b
prob <- (pu_a + pu_b) / (n_a + n_b)

se <- sqrt(prob * (1 - prob) * (1 / n_a + 1 / n_b))
x <- seq(-0.05, 0.075, by = 0.001)
plot(x, dnorm(x, prop_a - prob_b, se), type = 'l',
     ylab = 'dnorm(x)')
segments(0, 0, 0, 25)

pnorm(0, prop_a - prob_b, se)
qnorm(c(.025, .975), prop_a - prob_b, se)

prop.test(c(221, 210), c(1271, 1311))
